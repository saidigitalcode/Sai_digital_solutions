(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_0766a282._.js",
  "static/chunks/node_modules_framer-motion_dist_es_281669ff._.js",
  "static/chunks/node_modules_motion-dom_dist_es_acca53a6._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_three_build_three_core_df0bde7e.js",
  "static/chunks/node_modules_three_build_three_module_230a9f89.js",
  "static/chunks/node_modules_c7e28a5b._.js",
  "static/chunks/src_fe93a9df._.js"
],
    source: "dynamic"
});
